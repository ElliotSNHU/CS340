from pymongo import MongoClient
from bson.objectid import ObjectId
from pprint import pprint
from bson.json_util import dumps

class AnimalShelter(object):
    """ 
    CRUD operations for Animal collection in MongoDB 
    """

    def __init__(self, USER, PASS):
        """
        Initialize the AnimalShelter object with MongoDB connection parameters.

        :param USER: Username for MongoDB authentication
        :param PASS: Password for MongoDB authentication
        """
        USER = 'aacuser'
        PASS = 'password'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 32689
        DB = 'AAC'
        COL = 'animals'
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER, PASS, HOST, PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]
    
    def create(self, data):
        """
        Inserts a new document into the animals collection.

        :param data: A dictionary representing the document to be inserted
        :return: True if the document is inserted successfully, False otherwise
        :raises: Exception if the data is None
        """
        if data is not None:
            insertSuccess = self.database.animals.insert_one(data)
            if insertSuccess.inserted_id is not None:
                return True
            else:
                return False
        else:
            raise Exception("Cannot save an empty data field.")
    
    def read(self, criteria=None):
        """
        Retrieves documents from the animals collection.

        :param criteria: A dictionary representing the filter for querying documents
        :return: A list of documents matching the criteria, excluding the '_id' field
        """
        if criteria is not None:
            data = self.database.animals.find(criteria, {"_id": False})
        else:
            data = self.database.animals.find({}, {"_id": False})
        
        return list(data)
        
    def update(self, criteria, update_data):
        """
        Updates documents in the animals collection.

        :param criteria: A dictionary representing the filter for querying documents to update
        :param update_data: A dictionary representing the fields to update
        :return: True if at least one document is updated, False otherwise
        :raises: Exception if either criteria or update_data is None
        """
        if criteria is not None and update_data is not None:
            result = self.database.animals.update_one(criteria, {"$set": update_data})
            return result.modified_count > 0
        else:
            raise Exception("Unable to update, no criteria or update data provided")
    
    def delete(self, criteria):
        """
        Deletes documents from the animals collection.

        :param criteria: A dictionary representing the filter for querying documents to delete
        :return: True if at least one document is deleted, False otherwise
        :raises: Exception if criteria is None
        """
        if criteria is not None:
            result = self.database.animals.delete_one(criteria)
            return result.deleted_count > 0
        else:
            raise Exception("Unable to delete, no criteria provided")